package com.company;

public interface PracownikHali {
    void nadajStanowsiko();
    boolean sprawdzBadaniaLekarskie();
    void sprawdzAkord();
    void WyswietlInfo();

}
