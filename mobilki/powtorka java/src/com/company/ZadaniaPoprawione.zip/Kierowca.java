package com.company;

public interface Kierowca {
    void nadajPojazd(String nazwa, int numer);
    boolean sprawdzBadanieTechniczne();
    void wyswietlInformacje();

}
