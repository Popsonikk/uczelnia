package com.company;

public interface Pracownik {
    void przyznajPremie(double kwota);
    double obliczNetto();
    void dodajOstrzezenie(String tresc);
    void przyznajKare(double kwota);
}
