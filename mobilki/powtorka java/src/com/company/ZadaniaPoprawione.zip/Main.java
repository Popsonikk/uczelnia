package com.company;

public class Main {

    public static void main(String[] args)
    {
	    // zad1
        /*Kot kot1= new Kot("Mruczek","Szary","Pers",1,1);
        Kot kot2= new Kot("Kotek","Czarny","Dachowiec",2,4);
        Kot kot3= new Kot("Śnieszka","Biały","Domowy",5,5);*/
        //zad2
       /* Prostokat prostokat= new Prostokat();
        prostokat.czytajDane();
        System.out.println("pole wynosi "+prostokat.wyswietlWynik());*/
        //zad3
        /*Kalkulator kalkulator= new Kalkulator();
        kalkulator.zlozenie();*/
        //zad4
       /* Delta delta=new Delta();
        delta.czytajDane(1.0,3.0,2.0);
        delta.przetworDane();
        delta.wyswietlWynik();*/
        //zad5
       /* Lista lista=new LosowaLista();
        LosowaLista.licz_sume(lista.lista);
        LosowaLista.licz_srednia(lista.lista);
        LosowaLista.licz_najmniejsza(lista.lista);
        LosowaLista.licz_najwieksza(lista.lista);
        LosowaLista.wyswietl_info();*/


        //zad6
        /*Student s1= new LepszyStudent("Patryk","Popek","Chelm",303843);
        Student s2= new Student("Jakub","Kowalski","Lublin",302799);
        Student s3= new LepszyStudent("Andrzej","Nowak","Warszawa",291111);
       /* Informatyka inf=new Informatyka("wydzial","Prodziekan");
        inf.dodajStudenta(s1);
        inf.dodajStudenta(s2);
        inf.dodajStudenta(s3);
        inf.usunStudenta(s2);
        inf.pokazStudenta();*/
       /* double[]arr1= {4,4,4,5,5};
        double[]arr2= {4,4,5,5,5};
        s1.obliczSrednia(arr1);
        s3.obliczSrednia(arr2);
        s1.wyswieltInfo();
        s3.wyswieltInfo();*/



    }
}
