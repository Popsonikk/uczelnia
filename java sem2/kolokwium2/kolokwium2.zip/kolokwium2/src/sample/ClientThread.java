package sample;

import java.io.*;
import java.net.Socket;

public class ClientThread extends Thread{
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;



    public ClientThread(Socket socket) {

        this.socket = socket;
    }



    public void run(){
        try {
            InputStream input = socket.getInputStream();
            OutputStream output = socket.getOutputStream();
            reader = new BufferedReader(new InputStreamReader(input));
            writer = new PrintWriter(output, true);
            System.out.println("connected");
            while (true){

                getMessage();


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void send(String message){
        writer.println(message);
    }
    public String getMessage()
    {
         String message;
        try {
            message= reader.readLine();
            return message;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



}

