package com.company;

public interface ICDCodeTabular {
    String getDescription (String ICD_10)throws IndexOutOfBoundsException;
}
